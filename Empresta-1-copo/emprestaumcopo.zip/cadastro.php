<?php
	include_once "db_connect.php";
    $nome = $_POST["nome"];
    $sobrenome = $_POST["sobrenome"];
    $email = $_POST["email"];
	$num_mat = $_POST["NumMatricula"];
	$cpf = $_POST["CPF"];
	$senha= md5($_POST["senha"]);
    $telefone = $_POST["telefone"];
    $nome = $nome ." ". $sobrenome; 
  
    if (!$connect)
 {
 die('Erro: ' . mysql_error());
 }


  $sql = "INSERT INTO Usuario(Nome,Cpf,Num_Matricula,Senha,Email,Telefone) VALUES ('$nome','$cpf','$num_mat','$senha','$email','$telefone')";
	$resul = mysqli_query($connect,$sql);
        if($resul){
          echo "<script language='javascript' type='text/javascript'>alert('Usuário cadastrado com sucesso!');window.location.href='login.php'</script>";
        }else{
          echo "<script language='javascript' type='text/javascript'>alert('Não foi possível cadastrar esse usuário');window.location.href='register.html'</script>";
        }	
        
        mysql_close($connect);
?>